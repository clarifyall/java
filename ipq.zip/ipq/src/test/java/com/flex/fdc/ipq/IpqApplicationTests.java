package com.flex.fdc.ipq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpqApplicationTests {

	@Test
	void contextLoads() {
	}

}

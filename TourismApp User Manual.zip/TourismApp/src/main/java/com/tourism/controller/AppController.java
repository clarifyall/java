package com.tourism.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.tourism.entity.User;
import com.tourism.repo.UserRepository;

@Controller
public class AppController {

	@Autowired
	private UserRepository userRepo;


	List<String> citiesList;

	@ModelAttribute
	public void preLoad(Model model) {
		citiesList = new ArrayList<>();
		citiesList.add("Hyderabad");
		citiesList.add("Delhi");
		citiesList.add("Bangalore");
		citiesList.add("Chennai");
		citiesList.add("Ahmedabad");
		citiesList.add("Gujarat");
	}

	@GetMapping(value = "/cityList")
	public String home(Model model) {
		model.addAttribute("citiesList", citiesList);
		return "cityList";
	}

	@PostMapping(value = "/save")
	public String save(@ModelAttribute("cities") String city, Model model) {
		model.addAttribute("cityname", city.toString());
		return "citydisplay";
	}

	@GetMapping("/")
	public String viewHomePage() {
		return "index";
	}

	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User());

		return "signup_form";
	}

	@PostMapping("/process_register")
	public String processRegister(User user) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);

		userRepo.save(user);

		return "register_success";
	}

	@GetMapping("/users")
	public String listUsers(Model model) {
		List<User> listUsers = userRepo.findAll();
		model.addAttribute("listUsers", listUsers);

		return "users";
	}

	@GetMapping("/tourism")
	public String listTourism(Model model) {
		List<User> listUsers = userRepo.findAll();
		model.addAttribute("listUsers", listUsers);
		return "tourism";
	}
}
